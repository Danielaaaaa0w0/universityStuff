"improved_loop:\n\t"
    "vsetvli t0, %[arr_size], e16\n\t"

