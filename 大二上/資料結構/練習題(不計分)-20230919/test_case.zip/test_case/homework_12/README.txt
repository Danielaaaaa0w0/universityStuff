# Homework #12

Experiment with function weightedUnion(Program 5.20) and heightUnion to determine which one
produces better results when used in conjunction with function collapsingFind(Program 5.21).

# Technical Specification

* Perform the experiment.
* Write down your thought in the homework report.
* Remember to provide material(experiment result) to support your thought.